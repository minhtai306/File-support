Credits
=======

My thanks to the following people and organisations, without whom this
library wouldn't be what it is today. (Please let me know if I've
mistakenly omitted anyone.)

* Alen Zhou
* Andrew Hannon
* Andrew W. Donoho
* Andy Brett
* Andy Warwick
* Antoine Perdaens
* Ben Rimmington
* Blake Seely
* Cary Yang
* David Keegan
* Gabriel Handford
* George MacKerron
* Greg Bolsinga
* Hager Hu
* Hiroshi Saito
* Jakub Jelonek
* Jens Alfke
* Joerg Schwieder
* John Engelhart
* Konstantin Welke
* Lloyd Hilaiel
* Marc Lehmann
* Michael Papp
* Mike Monaco
* Ole André Vadla Ravnås
* Phill Baker
* Robert McNally
* Robin Lu
* Ryan Smale
* Sam Dean
* Sam Soffes
* Sean Scanlon
* Stig Brautaset
* The Adium Crew
* Tobias Höhmann
* Tod Karpinski
* Ullrich Schäfer
* Wolfgang Sourdeau
* aethereal
* boredzo
* dewvinci
* dmaclach
* jinksys
* jonkean
* lukef
* renerattur
* upsuper
